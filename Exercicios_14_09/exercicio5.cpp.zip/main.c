#include <stdio.h>

int main()
{
    int pao_de_queijo, refrigerante, suco, coxinha, total;
    
    printf("Digite a quantidade que você comeu de pão de queijo: \n");
    scanf("%d", &pao_de_queijo);
    
    printf("Digite a quantidade que você comeu de coxinha: \n");
    scanf("%d", &coxinha);
    
    printf("Digite a quantidade que você bebeu de refrigerante: \n");
    scanf("%d", &refrigerante);
    
    printf("Digite a quantidade que você bebeu de suco: \n");
    scanf("%d", &suco);
    
    total = pao_de_queijo * 5 + coxinha * 3 + refrigerante * 4 + suco * 2;
    
    printf("Total a pagar será: %d",total);
    
    return 0;
}

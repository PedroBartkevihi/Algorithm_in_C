#include <stdio.h>

int main()

{
    char a[100];
    int idade;
    
    printf("Qual o seu nome?\n");
    scanf("%s", a);
    
    printf("Qual sua idade?\n");
    scanf("%d", &idade);
    
    printf("Ola, %s, você tem %d anos", a, idade);
    
    return 0;
    
}
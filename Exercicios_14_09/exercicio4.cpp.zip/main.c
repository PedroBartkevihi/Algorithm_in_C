#include <stdio.h>

int main()
{
    float preco, total, preco_final;
    
    printf("Digite o preço do produto: \n");
    scanf("%f", &preco);
    
    preco_final = preco * 0.05;
    total = preco - preco_final;

    printf("O total a pagar será:%.2f", total);
    
    return 0;
}

#include <stdio.h>

int main()
{
    int dias;
    float km, total;
    
    printf("Digite o número de km percorridos: \n");
    scanf("%f", &km);
    
    printf("Digite o número de dias em que o carro permaneceu alugado: \n");
    scanf("%d", &dias);
    
    total = (90 * dias) + (0.20 * km);
    
    printf("Total a pagar será: %.2f", total);

    return 0;
}

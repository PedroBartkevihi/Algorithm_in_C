#include <stdio.h>

int main()
{
    int cigarros_por_dia, anos, vida_perdida;
    
    printf("Digite quantos cigarros por dia você fuma: \n");
    scanf("%d", &cigarros_por_dia);
    
    printf("Digite a quantos anos você fuma: \n");
    scanf("%d", &anos);
    
    vida_perdida = (cigarros_por_dia * 10 * anos * 365) / 1440;
    
    printf("Total de dias de vida perdidos: %d", vida_perdida);
    
    return 0;
}

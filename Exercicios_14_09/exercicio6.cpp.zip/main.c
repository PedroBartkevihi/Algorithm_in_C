#include <stdio.h>

int main()
{
    int dinheiro, bombom, preco_bombom, maximo;
    
    preco_bombom = 2;
    
    printf("Digite a quantidade de dinheiro que você possui: \n");
    scanf("%d", &dinheiro);
    
    printf("Digite a quantidade de bombom que deseja comprar: \n");
    scanf("%d", &bombom);
    
    maximo = dinheiro / preco_bombom;
    
    printf("Quantidade máxima de bombom que poderá comprar é: %d", maximo);
    
    return 0;
}
